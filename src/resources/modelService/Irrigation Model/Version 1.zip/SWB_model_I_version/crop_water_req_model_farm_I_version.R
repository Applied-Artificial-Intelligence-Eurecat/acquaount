##############################################   DATI DI INPUT  ###########################################################################################################
rm(list = ls())

library(tictoc)
library(readxl)
library(units)
library(lubridate)

#tic()


wd="C:/Users/Andrea/OneDrive - Università degli Studi di Sassari/Desktop/Dottorato_Sassari/modello_ACQUAOUNT/SWB_model_I_version/"
in_dir=paste(wd,"Input_data/",sep="")
out_dir=paste(wd,"Output_data/",sep="")

source(paste(wd,"Functions_model_farm_I_version.r",sep=""))


########################################## CROP AND IRRIGATION ##########################################################

#import crop table-------------------------------------------

crop_table=read.csv(paste(in_dir,"crop_data/crop_table.csv",sep="")) 


#Crop and irrigation data --------------------------------

crop_list=list("citrus")

d_spacing=0.6 #dripper spacing
d_rate=2.6 #dripper flowrate (l/h)
w_length=2000 #wetted length (m)


n_emitter=w_length/d_spacing #number of emitter
Flow_rate=n_emitter*d_rate/1000 #flowrate of the system #m^3/h

season_start=75
season_end=385

irr_given=read.csv(paste(in_dir,"irrigation_data/irr_given.csv",sep=""))
irr_given<-as.numeric(unlist(irr_given))

############################################### SOIL DATA #################################################

P_sand=60 #percentage of sand (%)
P_clay=30 #percentage of clay
P_silt=10 #percentage of silt

P_om=6 #percentage of organic matter

soil_AWC=0.4 #total available water content at saturation (soil porosity)
Ks=2.78 #cm/h   #Saturdated hydraulic conductivity
Pb=1.06 #g/cm3  #Bulk density


#derive coefficients of field capacity (-33 kPa) and wilting point (-1500 kPa) from Rawls et al. (1982) 
theta_fc=0.2576 - 0.0020*P_sand/100 + 0.0336*P_clay/100 + 0.0299*P_om/100 #field capacity (the water content that can be host by the soil without deep percolation)
theta_wp=0.026 + 0.005*P_clay/100 + 0.0158*P_om/100 #wilting point


crop_AWC= theta_fc - theta_wp #available water capacity for the crop

if(theta_fc>soil_AWC){
  soil_AWC=theta_fc
}else{
  soil_AWC=soil_AWC
}


############################################ CLIMATE DATA ##################################################

#Define climatic zone in which I will insert appropriate values of Kc and duration of the growing period

#In this case, we imagine dealing with 3 climatic zones: 
# 3: Sub-tropical winter rain (Mediterranean)
# 4: Oceanic temperate (Central Europe / England)
# 5: Sub-continental temperate (Po Valley / Eastern Europe)


climate_zone=3 #in this case we are focusing on Sardinia
lat=40 
elev=15

# Import data--------------------------------------

temp <- read.csv(paste(in_dir,"climate_data/temperature.csv",sep=""),header = FALSE) 
precipitation <- read.csv(paste(in_dir,"climate_data/precipitation.csv",sep=""),header = FALSE)
sw_rad <- read.csv(paste(in_dir,"climate_data/SW_rad.csv",sep=""),header = FALSE)
RH <- read.csv(paste(in_dir,"climate_data/rel_hum.csv",sep=""),header = FALSE)
wind <- read.csv(paste(in_dir,"climate_data/wind_sp.csv",sep=""),header = FALSE)

temp<-as.numeric(unlist(temp))
SW_rad<-as.numeric(unlist(sw_rad))
wind<-as.numeric(unlist(wind))
elev<-as.numeric(unlist(elev))
precipitation<-as.numeric(unlist(precipitation))

date <-read.csv(paste(in_dir,"climate_data/date.csv",sep=""),header = FALSE)
date <- ymd(as.character(unlist(date)))
hh <- read.csv(paste(in_dir,"climate_data/hour.csv",sep=""),header = FALSE)
hh<-as.numeric(unlist(hh))



############################################ MOISTURE DATA ##################################################

moisture_sensor <- read.table(paste(in_dir,"soil_moisture_data/soil_moisture.csv",sep=""),sep=";",header = TRUE) 



sensor_level=c(20,20,20,20,20,20)/100 #these are the cm between each level of recording of the sensor (eg., Soil_1=10-30 cm, Soil_2=30-50, ...)
level=array(NA,length(sensor_level))
level[1]=sensor_level[1]
level[2]=sensor_level[2]+level[1]
level[3]=sensor_level[3]+level[2]
level[4]=sensor_level[4]+level[3]
level[5]=sensor_level[5]+level[4]
level[6]=sum(sensor_level)







################################################ RUN MODEL ##################################################################




# CALCULATION ET0 ########################################################################

Evapotranspiration <- FAO_ET0_function(lat,temp,sw_rad,wind,RH,elev,date,hh,"°C","W/m2","m/s","%","m")
ET0=Evapotranspiration$ET0
OWET=Evapotranspiration$OWET


# DEFINE WIDTH OF WETTED AREA ###########################################################
#reconstruct the hourly wetting front of the subsurface drip irrigation from Al‐Ogaidi et al. (2015)
w_width=(40.489*d_rate^0.2717*Ks^(-0.2435)*moisture_sensor[,1]^0.1122*Pb^2.077*P_sand^(-0.1082)*P_silt^0.0852*P_clay^(-0.154))*2 #moisture_sensor[,3]=initial soil moisture at 20 cm. *2 is because from radius we convert it to diameter





# DEFINE THE OUTPUT FILES ##############################################################

Irr_req=as.numeric(array(0,dim=length(ET0)))
ETa_rf=as.numeric(array(0,dim=length(ET0)))
ETa_full=as.numeric(array(0,dim=length(ET0)))
ks=as.numeric(array(0,dim=length(ET0)))
Irr_vol=as.numeric(array(0,dim=length(ET0)))
Irr_to_apply=as.numeric(array(0,dim=length(ET0)))
moisture_mean_array=as.numeric(array(0,dim=length(ET0)))
Irr_vol_percolated=as.numeric(array(0,dim=length(ET0)))




# Convert the date into specific formats
j <- as.numeric(format(date, "%j")) #Julian day
year=as.numeric(format(date, "%Y")) #year
year_list=unique(year) #list of years of the simulation

l<-c(1:length(date)) #posizioni delle righe nel dataframe

#define the last day of each year, to understand if it's 365 or 366 days
end<-array(0,length(year_list))
end[length(year_list)]<-j[length(j)]
for (p in 1:(length(l)-1)){
  if(j[p]>j[p+1]){
    end[round(l[p]/365)]<-j[p]
  }
}


 

  

  
# SOIL WATER BALANCE ##############################################################
  
  
  
  
  for (crop in crop_list){
    

    
    i=which(crop==crop_list)
    r_crop=which(crop_table$Crop==crop & crop_table$Clim==climate_zone) #Define the r_crop where to take the data
    type=crop_table[r_crop,16]
    
    # Length of Growing Periods, kc values and rooting depth

    
    if (season_start<season_end){
      
      LGP=season_end-season_start+1
    } else if (season_start>season_end){
      
      LGP=season_end-season_start+366
    }
    
    
    #%definition of kc
    kc_in=crop_table[r_crop,4]
    kc_mid=crop_table[r_crop,5]
    kc_end=crop_table[r_crop,6]
    
    #Definition of period
    L1=round(LGP*crop_table[r_crop,7]) #Stage 1, that corresponds to LGP (in days) for the percentage of stage 1
    L2=round(LGP*crop_table[r_crop,8])
    L3=round(LGP*crop_table[r_crop,9])
    L4=LGP-(L1+L2+L3)
    
    L12=L1+L2
    L123=L1+L2+L3
    
    L2_den=L2
    ifelse(L2_den==0,NA,L2_den)
    L4_den=L4
    ifelse(L4_den==0,NA,L4_den)
    
    s=season_start
    h=season_end
    
    
    #definition of rooting depth
    
    RD=as.numeric(crop_table[r_crop,c(13,14)])
    
  
    
    L12_den=L12
    ifelse(L12_den==0,NA,L12_den)
    
    #Depletion factor
    DF=crop_table[r_crop,15]
    
    #irrigation type
    irr_type=crop_table[r_crop,17]
    
    #irrigation deficit
    irr_def_array=as.numeric(crop_table[r_crop,c(18:20)])
    
    
    
    
    
    # Define lower level of soil where we record data of deep percolation
    r=which(level>RD[2]+0.3)
    moisture_LOW<-as.numeric(moisture_sensor[,r[1]]) #the soil moisture recorded at 80 cm below surface
    
    #find natural fluctualtions (standard deviation) of moisture_LOW levels far from irrigation events --------------------------------------------------------------------------
    
    #method 1 (10 hours before irrigation)
    if(which(irr_given>0)[1]<10){x=which(irr_given>0)[1]+c(-which(irr_given>0)[1]:0)} else{x=which(irr_given>0)[1]+c(-10:0)} # select the 10 hours before an irrigation event. If the irrigation event occurs before 10 hours from the beginning of the simulation, select the possible hours
    # method 2 (take 24 values before an irrigation event only if irrigation happens 48 hours before)
    zeros=which(irr_given==0)
    transitions <- c(zeros[diff(zeros) != 1], tail(zeros, 1))
    k=c()
    for(b in 1:length(transitions)){
      if(transitions[b]-48 <0 ){ 
        k=c(k,0) 
      }else{
        if(sum(irr_given[transitions[b]-48]==0)){ # if no irrigation happens 48 hours before the irrigation event, take the 24 values of moisture_LOW before the irrigation event
          k=c(k,transitions[b]+c(-24:0))  
        }else{
          k=c(k,0)
        }
      }
      
    }
    # method 3 (take values 48 hours after last irrigation event)
    w=tail(which(irr_given>0),1)
    if(length(irr_given)-w > 48){y= c((tail(which(irr_given>0),1)+48):length(irr_given))} else{y=0} #if there are more than 48 hours between the last irrigation and the end of array, take the remaining values
    z=sort(unique(c(k,x,y)),decreasing = FALSE)
    z=z[z>0]
    sd_base=sd(moisture_LOW[z])
    
   
    
    
    
    ponding_in=0

     for(a in 1:length(l)){ #iterations from 48th hour to the 96th hour (2 days)
          day <- j[a]
          
          
       
        #Increment of Rooting depth----------------------------------------------------------------------
        
  
        
        daily_rooting_depth<-RD_increment(s,h,day,L12,RD,L12_den,type) 
        

        
        #Calculation of mean soil moisture in the soil---------------------------------------------------
        
        if(daily_rooting_depth < sum(sensor_level)){
          ll=c(sensor_level[which(daily_rooting_depth>level)],sensor_level[min(which(daily_rooting_depth<level))]) #select the levels covered by RD
          ll[length(ll)]=level[min(which(daily_rooting_depth<level))] - daily_rooting_depth # subtract the part which is below rooting depth
          
          if(a==1){
            moisture_a <- as.numeric(moisture_sensor[a,])
          }else{
            moisture_a <- as.numeric(moisture_sensor[a-1,]) #select the levels of moisture of the previous time step
          }
          moisture <- as.numeric(moisture_a[c(which(daily_rooting_depth>level),min(which(daily_rooting_depth<level)))])   
          
        }else{
          ll=sensor_level
          if(a==1){
            moisture_a <- as.numeric(moisture_sensor[a,])
          }else{
            moisture_a <- as.numeric(moisture_sensor[a-1,]) 
          }
          moisture <- moisture_a
        }
        
        
        
        moisture_mean=as.numeric(((moisture %*% ll)/daily_rooting_depth)/100) #here I'm making the weighted average of soil moisture over the levels covered by the RD. I divide by 100 because I want the result to be adimensional
        moisture_mean=ifelse(moisture_mean==Inf,0,moisture_mean)
        
        moisture_mean_array[a]=moisture_mean
        
        # Determination of effective rainfall prec_eff (from Ali&Mubarak, 2017) ------------------------------------


        prec_eff<-P_eff(daily_rooting_depth,soil_AWC,moisture_mean,ET0,a,precipitation)
        prec_eff<- prec_eff+ponding_in #the water that doesn't evaporate, then constitutes the "precipitation" of the following hour
        

        ponding_gross=ifelse(precipitation[a]>prec_eff,precipitation[a]-prec_eff,0) #define runoff/water that remains on the surface and doesn't infiltrate
        ponding_net=ifelse(OWET[a]<=ponding_gross, ponding_gross-OWET[a], ponding_gross)
        ponding_in=ponding_net
        
        
        # 1st step: increment of Soil Moisture due to Precipitation input----------------------------------------
        
        deficit_meteo <- (theta_fc-moisture_mean) * daily_rooting_depth * 1000 - prec_eff - irr_given[a]
        DP=ifelse(deficit_meteo < 0, abs(deficit_meteo),0) #deep percolation (the component of water that can't be hold in the soil and percolates due to gravity)
        
        deficit_meteo=ifelse(deficit_meteo<0,0,deficit_meteo)
        
     
        
           
        # 2nd step: calculation of daily crop coefficient----------------------------------------------------------
        
        
        kc<-crop_coeff(s,h,day,L1,L12,L123,L2_den,L4_den,LGP,kc_in,kc_mid,kc_end)
        
        
        
        # 3rd step: calculation of daily maximum water capacity in the rooting zone (TAW) and amount of water available until water stress occurs (RAW)
        
        TAW <- crop_AWC * 1000 * daily_rooting_depth
        RAW <- crop_AWC * 1000 * daily_rooting_depth * DF
        
        # 4th step: water-stress coefficient---------------------------------------------------------------------
        
        ks[a]<-ws_coeff(TAW,deficit_meteo,RAW)
        
        #5th step: correction of kc according to soil moisture--------------------------------------------------------------
        
        if(a<49){
          kc_corr=kc
        } else{
          if(irr_given[a-48]>0){
            
            #do the ratio between the standard deviation of moisture_LOW of the last 48 hours over the base one (with natual fluctuations)
            ratio_sd=sd(moisture_LOW[(a-48):a])/sd_base
            
            
            if(ratio_sd>2){
              #if the ratio between the standard deviation of moisture level (at 80 cm below surface) 48 hours after irrigation and the standard deviation of moisture in a period without irrigation is greater than 2, then correct kc
              
              kc_corr=kc*0.9 #or write kc=kc-0.1?
              
            } else if(deficit_meteo > (1-0.9) * theta_fc * daily_rooting_depth * 1000){
              
              #if deficit is greater than 10% of field capacity
              kc_corr=kc*1.1 #or write kc=kc+0.1?
            }
          }else{
            kc_corr=kc
          }
        }
        
        
           
        
        

        
        # 6th step: calculation of Actual Evapotranspiration
        ETc <-ET0[a] * kc_corr
        ETa <- ET0[a] * kc_corr * ks
        
        
        
        # 7th step: reduction of Soil Moisture due to Actual Evapotranspiration-------------------------------------
        
        deficit_final<-def_function(deficit_meteo,TAW,ETa)
        deficit_final_limit<-def_lim_function(TAW,ks,RAW)
        
   
        
        # 8th step: Calculation of evapotranspiration components and irrigation requirements------------------------------------------------------
        
        ETa_rf[a] <-ETa #ETa rainfed (If i never irrigate, but it only depends on precipitation)
        
        ETa_full[a] <-ETc #ETa in field capacity condition (ks=1)
        
        
 
        
        Irr_req[a] <- irrigation_function(ETa_rf,a,ETa_full,deficit_final,deficit_final_limit,ETa)
        
        
        
        
        #9th step: define irrigation volume -----------------------------------------------------------------------------
        
        # Efficiency of irr systems
        
        eff_G=0.65 #efficiency of gravity irrigation
        eff_S=0.75 #efficiency of sprinkler irrigation
        eff_D=0.90 #efficiency of drip irrigation
        
        
        # irrigation efficiency ---
        if(irr_type=="G"){
          eff_irr=eff_G
        } else if(irr_type=="S"){
          eff_irr=eff_S
        } else if(irr_type=="D"){
          eff_irr=eff_D
        }
        
        #Deficit irrigation ----
        if(day>s & day<s+L12){
          irr_def<-irr_def_array[1]
        } else if(day>s+L12 & day<s+L123){
          irr_def<-irr_def_array[2]
        } else if(day>s+L123 & day<h){
          irr_def<-irr_def_array[3]
        } else{
          irr_def<-1
        }
        
        
        
        
        Irr_vol[a] <- (Irr_req[a]/eff_irr * irr_def) * (w_width[a] * w_length) /1000  #irrigation volume in m3 (1000 is for the passage from mm of Irr_req to m)
        
        Irr_vol_full <-Irr_vol[a]/irr_def  #full irrigation volume (no deficit)
        
        
        #10th step: Decide when to irrigate --------------------------------------------------------------------------------------
        
        if(a<48){
          Irr_to_apply[a]=0
        } else{
          if(mean(ks[(a-12):a]) < 0.5 ){
            #if ks < 0.5 for the previous 12 hours, then irrigate
            
            Irr_to_apply[a]=Flow_rate 
            
            
          }else if(mean(ks[(a-12):a]) > 0.8 ){
            Irr_to_apply[a]=0
          }
          
        }
       
       
       #11th step: calculate volume percolated [m3]
        if(a<48){
          Irr_vol_percolated[a]=0
        }else{
          mean_moisture_nat=mean(moisture_LOW[z])
          mean_moisture_irr=mean(moisture_LOW[(a-48):a])
          
          if(mean_moisture_irr> 2*mean_moisture_nat){
            Irr_vol_percolated[a] <- (mean_moisture_irr - mean_moisture_nat) * 0.2 * (w_width[a] * w_length) #the difference of the mean natural moisture at 0.8 m and moisture after irrigation times 20 cm (the depth of that level) and he surface
          }
        }
        
         
       
        
          }
      
    
      
   }
  

  


write.table(ET0,paste(out_dir,"ET0.csv",sep=""),row.names = FALSE,col.names = FALSE)
write.table(moisture_LOW,paste(out_dir,"moisture_LOW.csv",sep=""),row.names = FALSE,col.names = FALSE)
write.table(ks,paste(out_dir,"ks.csv",sep=""),row.names = FALSE,col.names = FALSE)
write.table(Irr_vol,paste(out_dir,"Irr_vol.csv",sep=""),row.names = FALSE,col.names = FALSE)
write.table(Irr_vol_percolated,paste(out_dir,"Irr_vol_percolated.csv",sep=""),row.names = FALSE,col.names = FALSE)


